<?php if(session()->get('role_id')==2): ?>


<?php $__env->startSection('css'); ?>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/css/bootstrap-datepicker.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <div class="page-header">
        <h1><i class="glyphicon glyphicon-edit"></i> Coupons / Edit #<?php echo e($coupon->coupon_code); ?></h1>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">
        <div class="col-md-12">

            <form action="<?php echo e(route('coupons.update', $coupon->id)); ?>" method="POST">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                <div class="form-group <?php if($errors->has('coupon_code')): ?> has-error <?php endif; ?>">
                       <label for="coupon_code-field">Coupon_code</label>
                    <input type="text" id="coupon_code-field" name="coupon_code" class="form-control" value="<?php echo e(is_null(old("coupon_code")) ? $coupon->coupon_code : old("coupon_code")); ?>"/>
                       <?php if($errors->has("coupon_code")): ?>
                        <span class="help-block"><?php echo e($errors->first("coupon_code")); ?></span>
                       <?php endif; ?>
                    </div>
                    <div class="form-group <?php if($errors->has('website')): ?> has-error <?php endif; ?>">
                       <label for="website-field">Website</label>
                    <!-- <input type="text" id="website-field" name="website" class="form-control" value="<?php echo e(is_null(old("website")) ? $coupon->website : old("website")); ?>"/> -->
                       <?php if($errors->has("website")): ?>
                        <span class="help-block"><?php echo e($errors->first("website")); ?></span>
                       <?php endif; ?>

                       <select  id="website-field" name="website" class="form-control" >  
                       <?php foreach($items as $item): ?>
                       <option  value="<?php echo e($item->website); ?>"><?php echo e($item->website); ?></option>
                       <?php endforeach; ?>
                     </select>
                     
                    </div>
                    <div class="form-group <?php if($errors->has('description')): ?> has-error <?php endif; ?>">
                       <label for="description-field">Description</label>
                    <textarea class="form-control" id="description-field" rows="3" name="description"><?php echo e(is_null(old("description")) ? $coupon->description : old("description")); ?></textarea>
                       <?php if($errors->has("description")): ?>
                        <span class="help-block"><?php echo e($errors->first("description")); ?></span>
                       <?php endif; ?>
                    </div>
                    <div class="form-group <?php if($errors->has('expiry_date')): ?> has-error <?php endif; ?>">
                       <label for="expiry_date-field">Expiry_date</label>
                    <input type="text" id="expiry_date-field" name="expiry_date" class="form-control date-picker" value="<?php echo e(is_null(old("expiry_date")) ? date("d-m-Y", strtotime($coupon->expiry_date)) : old("expiry_date")); ?>"/>
                       <?php if($errors->has("expiry_date")): ?>
                        <span class="help-block"><?php echo e($errors->first("expiry_date")); ?></span>
                       <?php endif; ?>
                    </div>
                <div class="well well-sm">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <a class="btn btn-link pull-right" href="<?php echo e(route('coupons.index')); ?>"><i class="glyphicon glyphicon-backward"></i>  Back</a>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.0/js/bootstrap-datepicker.min.js"></script>
  <script>
    $('.date-picker').datepicker({
      format: 'dd-mm-yyyy'
    });
  </script>
<?php $__env->stopSection(); ?>

<?php else: ?>

    <script type="text/javascript">
        window.location = "<?php echo e(url('login')); ?>";
    </script>

<?php endif; ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>