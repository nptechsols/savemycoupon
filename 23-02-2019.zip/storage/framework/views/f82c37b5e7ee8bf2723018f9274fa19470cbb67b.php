<?php if(session()->get('role_id')==2): ?>



<?php $__env->startSection('header'); ?>
    <div class="page-header clearfix">
        <h1>
            <i class="glyphicon glyphicon-align-justify"></i> Coupons
            <a class="btn btn-success pull-right" href="<?php echo e(route('coupons.create')); ?>"><i class="glyphicon glyphicon-plus"></i> Create</a>
        </h1>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <?php if($coupons->count()): ?>
            
                 <?php foreach($coupons as $coupon): ?>
                    <div class="col-md-3">
                            <h5><b><?php echo e($coupon->coupon_code); ?></b></h5>
                            <img src="/storage/<?php echo e($coupon->website->logo); ?>" width="100px" height="100px"/>
                            <p><h5><b><?php echo e(date("d-m-Y", strtotime($coupon->expiry_date))); ?></h5></b></p>
                            <p><h5><b><?php echo e(@$coupon->website_id->website); ?></h5></b></p>
                                <p class="pull-left">
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('coupons.show', $coupon->id)); ?>"><i class="glyphicon glyphicon-eye-open"></i> </a>
                                    <a class="btn btn-xs btn-warning" href="<?php echo e(route('coupons.edit', $coupon->id)); ?>"><i class="glyphicon glyphicon-edit"></i> </a> &nbsp;
                                    <form action="<?php echo e(route('coupons.destroy', $coupon->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <button type="submit" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-trash"></i> </button>
                                    </form>
                                </p>
                                <br><br><br><br>
                    </div>  
                <?php endforeach; ?>
                  
                <?php echo $coupons->render(); ?>

            <?php else: ?>
                <h5 class="text-center alert alert-info">Empty!</h5>
            <?php endif; ?>

        </div>
  

<?php $__env->stopSection(); ?>

<?php else: ?>

    <script type="text/javascript">
        window.location = "<?php echo e(url('login')); ?>";
    </script>

<?php endif; ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>